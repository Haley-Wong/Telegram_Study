//
//  config.h
//  01-百思不得姐
//
//  Created by ruofei on 16/4/21.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#ifndef config_h
#define config_h

#define SETUP_API_ID(apiId) apiId = 40064;
#define SETUP_API_HASH(apiHash) apiHash = @"dc96d1bb53eebeb1da11864798c0f7a6";

#endif /* config_h */
