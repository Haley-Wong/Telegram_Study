/*
 * This is the source code of Telegram for iOS v. 1.1
 * It is licensed under GNU GPL v. 2 or later.
 * You should have received a copy of the license in this archive (see LICENSE).
 *
 * Copyright Peter Iakovlev, 2013.
 */

#import <Foundation/Foundation.h>

@interface TGMutableArrayWithIndices : NSObject

- (instancetype)initWithArray:(NSMutableArray *)array;

- (void)insertObject:(id)object atIndex:(NSUInteger)index;

- (NSArray *)objectsForInsertOperations:(__autoreleasing NSIndexSet **)indexSet;

@end
