#ifndef TelegraphKit_TGAppearance_h
#define TelegraphKit_TGAppearance_h

#ifdef __cplusplus
extern "C" {
#endif

bool TGBackdropEnabled();
    
#ifdef __cplusplus
}
#endif

#endif
