#import <Foundation/Foundation.h>

#import "TLObject.h"
#import "TLMetaRpc.h"


@interface TLaccount_PasswordInputSettings : NSObject <TLObject>


@end

@interface TLaccount_PasswordInputSettings$account_passwordInputSettings : TLaccount_PasswordInputSettings


@end

