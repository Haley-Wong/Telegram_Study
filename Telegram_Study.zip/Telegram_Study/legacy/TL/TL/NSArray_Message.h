#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_Message : NSObject <TLVector>


@end

