#import <Foundation/Foundation.h>

#import "TLObject.h"
#import "TLMetaRpc.h"


@interface TLchannels_MessageEditData : NSObject <TLObject>


@end

@interface TLchannels_MessageEditData$channels_messageEditDataMeta : TLchannels_MessageEditData


@end

