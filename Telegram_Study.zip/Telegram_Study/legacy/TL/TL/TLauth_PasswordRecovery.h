#import <Foundation/Foundation.h>

#import "TLObject.h"
#import "TLMetaRpc.h"


@interface TLauth_PasswordRecovery : NSObject <TLObject>

@property (nonatomic, retain) NSString *email_pattern;

@end

@interface TLauth_PasswordRecovery$auth_passwordRecovery : TLauth_PasswordRecovery


@end

