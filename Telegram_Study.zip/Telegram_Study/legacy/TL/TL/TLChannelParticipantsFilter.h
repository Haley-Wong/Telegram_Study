#import <Foundation/Foundation.h>

#import "TLObject.h"
#import "TLMetaRpc.h"


@interface TLChannelParticipantsFilter : NSObject <TLObject>


@end

@interface TLChannelParticipantsFilter$channelParticipantsRecent : TLChannelParticipantsFilter


@end

@interface TLChannelParticipantsFilter$channelParticipantsAdmins : TLChannelParticipantsFilter


@end

@interface TLChannelParticipantsFilter$channelParticipantsKicked : TLChannelParticipantsFilter


@end

