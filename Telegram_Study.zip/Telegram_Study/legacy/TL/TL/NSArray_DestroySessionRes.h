#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_DestroySessionRes : NSObject <TLVector>


@end

