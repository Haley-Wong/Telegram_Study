#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_BotCommand : NSObject <TLVector>


@end

