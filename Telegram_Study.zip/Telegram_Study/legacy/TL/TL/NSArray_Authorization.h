#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_Authorization : NSObject <TLVector>


@end

