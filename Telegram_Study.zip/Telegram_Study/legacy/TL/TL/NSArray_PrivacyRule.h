#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_PrivacyRule : NSObject <TLVector>


@end

