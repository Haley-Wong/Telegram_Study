#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_EncryptedMessage : NSObject <TLVector>


@end

