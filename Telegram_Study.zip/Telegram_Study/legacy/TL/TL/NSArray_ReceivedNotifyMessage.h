#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_ReceivedNotifyMessage : NSObject <TLVector>


@end

