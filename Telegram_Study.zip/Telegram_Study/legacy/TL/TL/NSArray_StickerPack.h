#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_StickerPack : NSObject <TLVector>


@end

