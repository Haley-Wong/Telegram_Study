#import <Foundation/Foundation.h>

#import "TLObject.h"
#import "TLMetaRpc.h"


@interface TLDcOption : NSObject <TLObject>


@end

@interface TLDcOption$dcOption : TLDcOption


@end

