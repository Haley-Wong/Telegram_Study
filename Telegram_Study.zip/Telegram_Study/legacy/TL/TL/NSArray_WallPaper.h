#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_WallPaper : NSObject <TLVector>


@end

