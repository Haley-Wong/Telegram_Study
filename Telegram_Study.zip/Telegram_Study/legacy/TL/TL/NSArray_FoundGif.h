#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_FoundGif : NSObject <TLVector>


@end

