#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_ChatParticipant : NSObject <TLVector>


@end

