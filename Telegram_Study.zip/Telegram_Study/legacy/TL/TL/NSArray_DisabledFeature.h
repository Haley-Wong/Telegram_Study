#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_DisabledFeature : NSObject <TLVector>


@end

