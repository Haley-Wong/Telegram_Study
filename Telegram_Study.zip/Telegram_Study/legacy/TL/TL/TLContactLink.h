#import <Foundation/Foundation.h>

#import "TLObject.h"
#import "TLMetaRpc.h"


@interface TLContactLink : NSObject <TLObject>


@end

@interface TLContactLink$contactLinkUnknown : TLContactLink


@end

@interface TLContactLink$contactLinkNone : TLContactLink


@end

@interface TLContactLink$contactLinkHasPhone : TLContactLink


@end

@interface TLContactLink$contactLinkContact : TLContactLink


@end

