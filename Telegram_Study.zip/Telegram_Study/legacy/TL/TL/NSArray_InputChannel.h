#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_InputChannel : NSObject <TLVector>


@end

