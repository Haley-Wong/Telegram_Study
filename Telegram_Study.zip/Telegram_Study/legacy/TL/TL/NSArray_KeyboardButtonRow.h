#import <Foundation/Foundation.h>

#import "TLObject.h"


@interface NSArray_KeyboardButtonRow : NSObject <TLVector>


@end

