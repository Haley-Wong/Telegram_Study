#import <Foundation/Foundation.h>

#import "TLObject.h"
#import "TLMetaRpc.h"


@interface TLBotInlineMessage : NSObject <TLObject>

@property (nonatomic, retain) NSString *caption;

@end

@interface TLBotInlineMessage$botInlineMessageMediaAuto : TLBotInlineMessage


@end

