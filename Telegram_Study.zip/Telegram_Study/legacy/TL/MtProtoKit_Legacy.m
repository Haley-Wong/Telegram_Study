//
//  MTProtoKit.m
//  MTProtoKit
//
//  Created by Peter on 15/02/14.
//  Copyright (c) 2014 Telegram LLC. All rights reserved.
//

#import "MtProtoKit_Legacy.h"

@implementation MTProtoKit

@end
